const date = new date();

const monthDay = document.querySelector('.day');
const lastDay = new Date(date.getFULLYEAR(),date.getMonth()+1,0).getDate();


const month = [
"Janauary",
"February",
"March",
"April",
"May",
"June",
"July",
"August",
"September",
"November",
"December"
];
document.querySelector("date.h1").inner.HTML=month[date.getMonth()];

document.querySelector('.date p').innerHTML=date.toDateString();

let day = "";
for(let i=1;i<=lastDay;i++)
{
	day+='<div>${i}</div>';
	monthDay.innerHTML = day;
}